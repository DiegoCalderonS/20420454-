
package paquete;



public class Principal {
    
    public static void main(String[] args) {
        JFrameVentana objVentana = new JFrameVentana();
        
        objVentana.setVisible(true);
        
    }
  
}
